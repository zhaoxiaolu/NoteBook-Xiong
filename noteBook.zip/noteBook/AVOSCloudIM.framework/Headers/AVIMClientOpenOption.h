//
//  AVIMClientOpenOption.h
//  AVOS
//
//  Created by Tang Tianyong on 1/8/16.
//  Copyright © 2016 LeanCloud Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AVIMClientOpenOption : NSObject

@property (nonatomic, assign) BOOL force;

@end
