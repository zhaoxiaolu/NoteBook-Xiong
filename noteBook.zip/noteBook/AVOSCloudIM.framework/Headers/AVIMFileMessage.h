//
//  AVIMFileMessage.h
//  AVOS
//
//  Created by Tang Tianyong on 7/30/15.
//  Copyright (c) 2015 LeanCloud Inc. All rights reserved.
//

#import <AVOSCloudIM/AVOSCloudIM.h>

/**
 *  文件消息类
 */
@interface AVIMFileMessage : AVIMTypedMessage <AVIMTypedMessageSubclassing>

@end
