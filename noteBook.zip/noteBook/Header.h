//
//  Header.h
//  account book
//
//  Created by xionghuanxin on 6/22/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#ifndef Header_h
#define Header_h


#endif /* Header_h */
/*
已实现:       自定义tabbar:遍历tabbaritem,改变属性;kvc狸猫换太子。
             代理:双代理,以及为什么不将代理直接给button
             类目方法封装:
             文件树:
             屏幕尺寸:
 
实现一半:     数据清空
         
暂未实现:     授权公开
             pickerview更换谓词:为什么叫谓词
             结果中筛选
             多时间节点云储存，选择恢复节点
             手动，自动上传
             动态创建表单？
 */