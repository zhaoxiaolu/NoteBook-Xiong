//
//  CoreDataRecord+CoreDataProperties.m
//  account book
//
//  Created by xionghuanxin on 6/21/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "CoreDataRecord+CoreDataProperties.h"

@implementation CoreDataRecord (CoreDataProperties)

@dynamic date;
@dynamic accountType;
@dynamic describe;
@dynamic recordType;
@dynamic money;
@dynamic remark;
@dynamic remarkPictureName;
@dynamic hidden;

@end

