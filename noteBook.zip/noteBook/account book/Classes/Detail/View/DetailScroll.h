//
//  DetailScroll.h
//  account book
//
//  Created by xionghuanxin on 6/16/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailScroll : UIScrollView

@end
