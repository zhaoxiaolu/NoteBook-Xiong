//
//  DetailCell.h
//  account book
//
//  Created by xionghuanxin on 6/16/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailCell : UITableViewCell
@property(nonatomic,strong)UIImageView *icomImageView;
@property(nonatomic,strong)UILabel *incomeLabel;
@property(nonatomic,strong)UILabel *costLabel;

@end
