//
//  KeyBoardView.h
//  account book
//
//  Created by xionghuanxin on 6/17/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyBoardView : UIView
@property(nonatomic,assign)CGFloat amount;
@property(nonatomic,strong)NSString *decribe;

@end
