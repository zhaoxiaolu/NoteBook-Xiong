//
//  DisplayView.h
//  account book
//
//  Created by xionghuanxin on 6/19/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisplayView : UIView
@property(nonatomic,strong)UILabel *typeLabel;
@property(nonatomic,strong)UILabel *amountLabel;
@property(nonatomic,strong)UILabel *decribeLabel;
@property(nonatomic,strong)UIImageView *typeImage;

@end
