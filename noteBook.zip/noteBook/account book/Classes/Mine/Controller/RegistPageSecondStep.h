//
//  RegistPageSecondStep.h
//  account book
//
//  Created by xionghuanxin on 7/1/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistPageSecondStep : UIViewController
@property(nonatomic,strong)NSString *phoneNumeber;

@end
