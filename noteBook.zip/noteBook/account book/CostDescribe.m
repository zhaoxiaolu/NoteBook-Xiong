//
//  CostDescribe.m
//  account book
//
//  Created by xionghuanxin on 6/22/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import "CostDescribe.h"

@implementation CostDescribe

// Insert code here to add functionality to your managed object subclass
+(NSString *)entityName
{
    return @"CostDescribe";
}

@end
