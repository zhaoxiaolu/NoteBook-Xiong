//
//  DescribePlist.m
//  account book
//
//  Created by xionghuanxin on 6/22/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//

#import "DescribePlist.h"

@implementation DescribePlist

// Insert code here to add functionality to your managed object subclass
+(NSString *)entityName
{
    return @"DescribePlist";
}

@end
