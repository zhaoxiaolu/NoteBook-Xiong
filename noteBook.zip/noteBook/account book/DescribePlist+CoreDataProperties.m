//
//  DescribePlist+CoreDataProperties.m
//  account book
//
//  Created by xionghuanxin on 6/22/16.
//  Copyright © 2016 xionghuanxin. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "DescribePlist+CoreDataProperties.h"

@implementation DescribePlist (CoreDataProperties)

@dynamic describe;
@dynamic imageName;

@end
